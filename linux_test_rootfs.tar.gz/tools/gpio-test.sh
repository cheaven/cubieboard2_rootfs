#!/bin/ash

if lsmod |grep gpio_test
then
     rmmod gpio_test
else
      modprobe gpio-test
fi


