#!/bin/ash

while true; do

ping -c 5 192.168.1.1
if [ "$?" = "0" ]; then
infow 5 0 EMAC ok
logw "ping 5 times ok"
else
infow 5 1 EMAC "ping failed"
logw "ping 5 times failed"
fi

done
